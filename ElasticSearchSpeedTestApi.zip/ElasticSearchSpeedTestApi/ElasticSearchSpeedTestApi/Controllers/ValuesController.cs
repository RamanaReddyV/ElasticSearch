﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Elasticsearch.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Nest;

namespace ElasticSearchSpeedTestApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private IConfiguration configuration;
        public static string CONNECTION_STRING = string.Empty;
        public static string INDEX_NAME = "elastic_search_sales";
        public static string INDEX_TYPE = "salesreport";

        public ValuesController(IConfiguration iConfig)
        {
            configuration = iConfig;
            CONNECTION_STRING = configuration.GetSection("ConnectionStr").GetSection("DefaultConnection").Value;
        }

        // GET api/values
        [HttpGet]
        public IActionResult Get()
        {
            // var result = GetAllRecords("Snacks");
            // return Ok(result);
            return Ok("test");
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {

            return "value";
        }

        // POST api/values
        [HttpPost]
        public IActionResult Post([FromBody] string value)
        {
           // 1.Elastic Search
          var result = ConfigureES(value);
            return Ok(result.Count());

            //// 2. SQL Search Queries...
            //var result = GetAllRecords(value);
            //return Ok(result.Count());
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        public static List<Salesreport> ConfigureES(string inputText)
        {
            List<Salesreport> salesReports = new List<Salesreport>();

            // 1. Connection URL's elastic search
            var listOfUrls = new Uri[]
            {
                // here we can set multple connectionn URL's...
                 new Uri("http://localhost:9200/")
            };

            StaticConnectionPool connPool = new StaticConnectionPool(listOfUrls);
            ConnectionSettings connSett = new ConnectionSettings(connPool);
            ElasticClient eClient = new ElasticClient(connSett);

            //  var see = eClient.DeleteIndex(INDEX_NAME);

            // check the connection health
            var checkClusterHealth = eClient.ClusterHealth();
            if (checkClusterHealth.ApiCall.Success && checkClusterHealth.IsValid)
            {
                // 2. check the index exist or not 
                var checkResult = eClient.IndexExists(INDEX_NAME);
                if (!checkResult.Exists)
                {
                    // Raise error to Index not avaliable
                }

                // Search All fileds in a documet type 
                //var response = eClient.Search<Salesreport>(s => s
                //.Index(INDEX_NAME)
                //.Type(INDEX_TYPE)
                //.Query(q => q.QueryString(qs => qs.Query(inputText + "*"))));



                // Search particular text field 
                var searchResponse = eClient.Search<Salesreport>(s => s.Index(INDEX_NAME).Type(INDEX_TYPE).From(0).Size(5000).Scroll("10m")
                                                                            .Query(q => q
                                                                                .Match(m => m
                                                                                    .Field(f => f.Itemtype)
                                                                                    .Query(inputText)

                                                                                )
                                                                            )
                                                                        );



                //var results = eClient.Scroll<Salesreport>("10m", searchResponse.ScrollId);
                while (searchResponse.Documents.Any())
                {
                    var res = searchResponse.Documents;
                    var sds = res.Cast<Salesreport>();
                    salesReports.AddRange(sds);
                    searchResponse = eClient.Scroll<Salesreport>("10m", searchResponse.ScrollId);
                }

                if (salesReports.Count > 0)
                {

                }
                else
                {

                }

                //var lastRecordResponse = eClient.Search<Salesreport>(s => s
                //    .Index(INDEX_NAME)
                //    .Type(INDEX_TYPE)
                //    .From(0)
                //    .Size(1).Sort(sr => sr.Descending(f => f.Region)));

                if (searchResponse.ApiCall.Success && searchResponse.IsValid)
                {

                }
                else
                {
                    // fail log the exception further use
                    var exception = searchResponse.OriginalException.ToString();
                    var debugException = searchResponse.DebugInformation.ToString();
                }
            }
            else
            {
                // fail log the exception further use
                var exception = checkClusterHealth.OriginalException.ToString();
                var debugException = checkClusterHealth.DebugInformation.ToString();
            }

            return salesReports;
        }

        public static List<Salesreport> GetAllRecords(string itemType)
        {
            List<Salesreport> salesReports = new List<Salesreport>();

            string sqlQuery = String.Format(@"
SELECT SR.Id AS Salesid,SO.Id AS Orderid,SP.Id AS Priceid,Sr.Region,SR.Itemtype,SO.Orderdate,SP.Unitprice,SP.Totalrevenue FROM dbo.SalesReport SR WITH(NOLOCK) 
INNER JOIN dbo.SalesOrder SO WITH (NOLOCK)  ON SR.Id=SO.SalesReportId
INNER JOIN dbo.SalesPrice SP WITH (NOLOCK)  ON SO.Id=SP.SalesOrderId where SR.Itemtype like '%{0}%'", itemType);
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                {
                    command.CommandTimeout = 1000;
                    using (SqlDataReader dataReader = command.ExecuteReader())
                    {

                        if (dataReader.HasRows)
                        {
                            while (dataReader.Read())
                            {
                                Salesreport salesR = new Salesreport();

                                salesR.Salesid = Convert.ToInt64(dataReader["Salesid"]);
                                salesR.Orderid = Convert.ToInt64(dataReader["Orderid"]);
                                salesR.Priceid = Convert.ToInt64(dataReader["Priceid"]);
                                salesR.Region = Convert.ToString(dataReader["Region"]);
                                salesR.Itemtype = Convert.ToString(dataReader["Itemtype"]);
                                salesR.Orderdate = Convert.ToString(dataReader["Orderdate"]);
                                salesR.Unitprice = Convert.ToString(dataReader["Unitprice"]);
                                salesR.Totalrevenue = Convert.ToString(dataReader["Totalrevenue"]);

                                salesReports.Add(salesR);
                            }
                        }
                    }
                }
                connection.Close();
            }

            return salesReports;
        }
    }
    public static class ElasticSearchUtility
    {




    }
    public class Salesreport
    {
        public long Salesid { get; set; }
        public long Orderid { get; set; }
        public long Priceid { get; set; }
        public string Region { get; set; }
        public string Itemtype { get; set; }
        public string Orderdate { get; set; }
        public string Unitprice { get; set; }
        public string Totalrevenue { get; set; }
    }
}
